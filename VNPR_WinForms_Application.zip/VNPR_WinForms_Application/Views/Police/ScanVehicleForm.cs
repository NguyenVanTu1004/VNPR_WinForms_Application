﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VNPR_WinForms_Application.Views.Police
{
    public partial class ScanVehicleForm : Form
    {
        public ScanVehicleForm()
        {
            InitializeComponent();
        }
    }
}
