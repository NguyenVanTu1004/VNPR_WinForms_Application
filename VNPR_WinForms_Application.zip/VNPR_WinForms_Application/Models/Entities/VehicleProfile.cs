﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VNPR_WinForms_Application.Models.Entities
{
    class VehicleProfile
    {
    }
}
